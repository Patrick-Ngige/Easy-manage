<?php 
/**
*
* @package easy-manage
*/

if(!defined('WP_UNINSTALL_PLUGIN')){
    die;
    }